from flask  import *
app = Flask(__name__)

@app.route("/")
def login():
	return render_template("log.html")

@app.route("/register")
def register():
	return render_template("register.html")

if __name__ == '__main__':
    app.run(debug = True)
